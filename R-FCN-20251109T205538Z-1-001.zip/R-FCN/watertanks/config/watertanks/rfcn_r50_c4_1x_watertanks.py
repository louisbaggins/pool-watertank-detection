_base_ = [
    '../_base_/models/rfcn_r50_c4.py',
    '../_base_/datasets/coco_detection.py',
    '../_base_/schedules/schedule_1x.py',
    '../_base_/default_runtime.py'
]

# Dataset
data_root = '/content/drive/MyDrive/TCC/campinas_dataset/'

metainfo = dict(classes=('piscina',))

train_dataloader = dict(
    batch_size=2,
    num_workers=2,
    dataset=dict(
        data_root=data_root + 'train/',
        ann_file='annotation/instances_train.json',
        data_prefix=dict(img='image/'),
        metainfo=metainfo)
)

val_dataloader = dict(
    batch_size=1,
    num_workers=2,
    dataset=dict(
        data_root=data_root + 'val/',
        ann_file='annotation/instances_val.json',
        data_prefix=dict(img='image/'),
        metainfo=metainfo)
)

test_dataloader = dict(
    batch_size=1,
    num_workers=2,
    dataset=dict(
        data_root=data_root + 'test/',
        ann_file='annotation/instances_test.json',
        data_prefix=dict(img='image/'),
        metainfo=metainfo)
)

val_evaluator = dict(ann_file=data_root + 'val/annotation/instances_val.json')
test_evaluator = dict(ann_file=data_root + 'test/annotation/instances_test.json')


# Config treino
max_epochs = 12
train_cfg = dict(max_epochs=max_epochs, val_interval=1)

optim_wrapper = dict(
    optimizer=dict(type='SGD', lr=0.0025, momentum=0.9, weight_decay=0.0001))

param_scheduler = [
    dict(type='MultiStepLR', milestones=[8, 11], end=12)
]

default_hooks = dict(
    checkpoint=dict(type='CheckpointHook', interval=1, max_keep_ckpts=3)
)
